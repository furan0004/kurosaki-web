package com.dmm.app.auth.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.dmm.app.auth.base.BaseActivity;
import com.dmm.app.auth.connection.LoginConnection;
import com.dmm.app.auth.entity.SaveLoginInfo;
import com.dmm.app.auth.entity.UserInfo;
import com.dmm.app.auth.entity.connection.LoginResult;
import com.dmm.app.auth.util.AuthUtil;
import com.dmm.app.base.Define;
import com.dmm.app.common.DmmCommonUtil;
import com.dmm.app.common.R;
import com.dmm.app.connection.DmmApiError;
import com.dmm.app.connection.DmmListener;
import com.dmm.app.member.connection.GetAddMemberInfosEnableConnection;
import com.dmm.app.member.entity.GetAddMemberInfosEnableEntity;
import com.dmm.app.notification.DmmUpdateNotification;
import com.dmm.app.util.Encryptor;
import com.dmm.asdk.core.store.GetHomeInfoConnection;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends BaseActivity implements OnClickListener {
    public static final String APP_STORE = "appstore";
    public static final String CANCELD_LOGIN = "CANCELD_LOGIN";
    public static final String LOGIN_SUCCESS = "ログインしました。";
    public static final String LOGOUT_OFF = "ログアウト済みです。";
    public static final String LOGOUT_SUCCESS = "ログアウトしました。";
    private int appCode;
    private Button closeBtn;
    private ImageButton forgetBtn;
    private boolean isR18;
    private ImageButton loginButton;
    private String loginId;
    private EditText loginText;
    private String pass;
    private EditText passwordText;
    private boolean useOnResult;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initViews();
        Intent intent = getIntent();
        this.isR18 = intent.getBooleanExtra("extraLoginToR18", false);
        this.useOnResult = intent.getBooleanExtra("loginActivityRefererUserOnResult", false);
        this.appCode = AuthUtil.getAppType(getPackageName());
        updateSaveLoginStatus();
    }

    private void initViews() {
        this.loginButton = (ImageButton) findViewById(R.id.loginButton);
        this.loginButton.setOnClickListener(this);
        this.forgetBtn = (ImageButton) findViewById(R.id.loginIdPassForgot);
        this.forgetBtn.setOnClickListener(this);
        this.closeBtn = (Button) findViewById(R.id.closebutton);
        this.closeBtn.setOnClickListener(this);
        this.loginText = (EditText) findViewById(R.id.loginId);
        this.passwordText = (EditText) findViewById(R.id.loginPassword);
        Toast.makeText(getApplicationContext(), getString(R.string.message_login), 1).show();
    }

    public void onClick(View v) {
        if (v.getId() == R.id.loginButton) {
            connJpStatus();
        } else if (v.getId() == R.id.loginIdPassForgot) {
            goToPasswordForgotScreen();
        } else if (v.getId() == R.id.closebutton) {
            if (this.useOnResult) {
                Intent data = new Intent();
                data.putExtra("loginErrorMessageFromPortalApp", "CANCELD_LOGIN");
                setResult(0, data);
            }
            finish();
        }
    }

    protected void onResume() {
        super.onResume();
        if (this.appCode == 2) {
            DmmUpdateNotification.getInstance().checkUpdateFromLogin(APP_STORE, this);
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4 && this.useOnResult) {
            Intent data = new Intent();
            data.putExtra("loginErrorMessageFromPortalApp", "CANCELD_LOGIN");
            setResult(0, data);
        }
        return super.onKeyDown(keyCode, event);
    }

    private void connJpStatus() {
        if (this.loginText.getText().toString().equals("") || this.passwordText.getText().toString().equals("")) {
            Toast.makeText(this, "ログインID、またはパスワードが未入力です。", 1).show();
            return;
        }
        HashMap<String, String> params = new HashMap();
        params.put("email", this.loginText.getText().toString());
        new GetAddMemberInfosEnableConnection(this, params, GetAddMemberInfosEnableEntity.class, new DmmListener<GetAddMemberInfosEnableEntity>() {
            public void onResponse(GetAddMemberInfosEnableEntity response) {
                try {
                    LoginActivity.this.login(response.getData().getJpStatus());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            public void onErrorResponse(DmmApiError error) {
                try {
                    LoginActivity.this.login(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError response) {
                if (LoginActivity.this.useOnResult) {
                    Intent data = new Intent();
                    data.putExtra("loginErrorMessageFromPortalApp", response.getMessage());
                    LoginActivity.this.setResult(0, data);
                }
                LoginActivity.this.dismissLoading();
            }
        }).connection(Boolean.valueOf(false));
        showLoading();
    }

    private void login(String jpStatus) throws Exception {
        this.loginId = this.loginText.getText().toString();
        this.pass = this.passwordText.getText().toString();
        Map<String, String> params = new HashMap();
        if (this.loginId.length() <= Define.USER_ID_LENGTH.intValue()) {
            params.put("loginId", this.loginId);
        } else {
            params.put("email", this.loginId);
        }
        String agent = AuthUtil.getApiUserAgent(getApplicationContext(), this.appCode);
        String kind = AuthUtil.getLoginKind(this.appCode);
        params.put("password", this.pass);
        params.put("jpStatus", jpStatus);
        params.put("isAdult", iSAdult());
        params.put("remoteAddress", "");
        if (kind != null) {
            params.put("loginKind", kind);
        }
        params.put("userAgent", agent);
        params.put("httpAcceptLanguage", "ja");
        params.put("appTerminalId", new UserInfo(this).generateUuid());
        if (!new LoginConnection(this, params, LoginResult.class, new DmmListener<LoginResult>() {
            public void onResponse(LoginResult response) {
                LoginActivity.this.saveLoginId();
                LoginActivity.this.savePassWd();
                LoginActivity.this.doAuthInit(response);
                if (LoginActivity.this.useOnResult) {
                    Intent data = new Intent();
                    data.putExtra("inputId", LoginActivity.this.loginId);
                    data.putExtra("play_movie_file_dir", LoginActivity.this.getIntent().getStringExtra("play_movie_file_dir"));
                    data.putExtra("play_movie_file_name", LoginActivity.this.getIntent().getStringExtra("play_movie_file_name"));
                    LoginActivity.this.setResult(-1, data);
                }
                Toast.makeText(LoginActivity.this.getApplicationContext(), "ログインしました。", 1).show();
                LoginActivity.this.dismissLoading();
                LoginActivity.this.finish();
            }

            public void onErrorResponse(DmmApiError error) {
                Toast.makeText(LoginActivity.this, new DmmApiError(error.getErrorCode()).getErrorMessage(), 1).show();
                String url = error.getErrorUrl();
                if (!url.isEmpty()) {
                    LoginActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                    LoginActivity.this.finish();
                }
                if (LoginActivity.this.useOnResult) {
                    Intent data = new Intent();
                    data.putExtra("loginErrorMessageFromPortalApp", error.getErrorMessage());
                    LoginActivity.this.setResult(0, data);
                }
                LoginActivity.this.dismissLoading();
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError response) {
                if (LoginActivity.this.useOnResult) {
                    Intent data = new Intent();
                    data.putExtra("loginErrorMessageFromPortalApp", response.getMessage());
                    LoginActivity.this.setResult(0, data);
                }
                LoginActivity.this.dismissLoading();
            }
        }).connection().booleanValue() && this.useOnResult) {
            Intent data = new Intent();
            data.putExtra("loginErrorMessageFromPortalApp", "data check Error");
            setResult(0, data);
        }
    }

    private void doAuthInit(LoginResult response) {
        new UserInfo(getApplicationContext()).saveUserInfo(response);
    }

    private String iSAdult() {
        if (this.isR18) {
            return "1";
        }
        return GetHomeInfoConnection.ISADULT_FALSE;
    }

    private void goToPasswordForgotScreen() {
        String url = "";
        if (this.isR18) {
            url = String.format("https://www.%s/my/-/passwordreminder/", new Object[]{"dmm.co.jp"});
        } else if (!this.isR18) {
            url = String.format("https://www.%s/my/-/passwordreminder/", new Object[]{"dmm.com"});
        }
        forwardUrl(url);
    }

    private void forwardUrl(String url) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
    }

    private void saveLoginId() {
        boolean isChecked = ((CheckBox) findViewById(R.id.loginChkSaveId)).isChecked();
        EditText loginText = (EditText) findViewById(R.id.loginId);
        SaveLoginInfo info = new SaveLoginInfo(getApplicationContext());
        if (!isChecked || DmmCommonUtil.isEmpty(loginText.getText().toString())) {
            info.setSaveLoginId(null);
        } else {
            info.setSaveLoginId(loginText.getText().toString());
        }
        info.setSaveLoginIdCheck(isChecked);
    }

    private void savePassWd() {
        EditText passwordText = (EditText) findViewById(R.id.loginPassword);
        boolean isChecked = ((CheckBox) findViewById(R.id.loginChkSavePasswd)).isChecked();
        SaveLoginInfo info = new SaveLoginInfo(getApplicationContext());
        Key k = Encryptor.generateKey(getApplicationContext());
        if (!isChecked || DmmCommonUtil.isEmpty(passwordText.getText().toString())) {
            info.setSavePasswdHash(null);
        } else {
            try {
                info.setSavePasswdHash(Base64.encodeToString(Encryptor.encrypt(passwordText.getText().toString().getBytes(), k), 1));
            } catch (GeneralSecurityException e) {
                e.printStackTrace();
                info.setSavePasswdHash(null);
            }
        }
        info.setSavePasswdCheck(isChecked);
    }

    private void updateSaveLoginStatus() {
        SaveLoginInfo info = new SaveLoginInfo(getApplicationContext());
        CheckBox loginChkSaveIdBtn = (CheckBox) findViewById(R.id.loginChkSaveId);
        EditText loginText = (EditText) findViewById(R.id.loginId);
        CheckBox loginChkSavePasswd = (CheckBox) findViewById(R.id.loginChkSavePasswd);
        EditText passwordText = (EditText) findViewById(R.id.loginPassword);
        if (info.getSaveLoginIdCheck()) {
            loginChkSaveIdBtn.setChecked(true);
        } else {
            loginChkSaveIdBtn.setChecked(false);
        }
        String tmpId = info.getSaveLoginId();
        if (!loginChkSaveIdBtn.isChecked() || DmmCommonUtil.isEmpty(tmpId)) {
            loginText.setText("");
        } else {
            loginText.setText(tmpId);
        }
        if (info.getSavePasswdIdCheck()) {
            loginChkSavePasswd.setChecked(true);
        } else {
            loginChkSavePasswd.setChecked(false);
        }
        passwordText.setText("");
        if (loginChkSavePasswd.isChecked() && !DmmCommonUtil.isEmpty(info.getSavePasswdHash())) {
            String pass = showPassWd();
            if (!DmmCommonUtil.isEmpty(pass)) {
                passwordText.setText(pass);
            }
        }
    }

    @SuppressLint({"NewApi"})
    private String showPassWd() {
        String result = new SaveLoginInfo(getApplicationContext()).getSavePasswdHash();
        if (DmmCommonUtil.isEmpty(result)) {
            return "";
        }
        byte[] plain = Encryptor.decrypt(Base64.decode(result, 1), Encryptor.generateKey(getApplicationContext()));
        if (plain == null) {
            return "";
        }
        return new String(plain);
    }
}
