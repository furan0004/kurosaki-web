package com.dmm.app.auth.base;

import android.app.ProgressDialog;
import com.dmm.app.common.ManagedActivity;
import com.dmm.app.common.R;

public class BaseActivity extends ManagedActivity {
    private ProgressDialog progressDialog;

    protected void showLoading() {
        if (this.progressDialog == null) {
            this.progressDialog = new ProgressDialog(this);
            this.progressDialog.setMessage(getString(R.string.dialog_msg_loading));
            this.progressDialog.setCanceledOnTouchOutside(false);
        }
        this.progressDialog.show();
    }

    protected void dismissLoading() {
        if (this.progressDialog != null) {
            this.progressDialog.dismiss();
        }
    }
}
