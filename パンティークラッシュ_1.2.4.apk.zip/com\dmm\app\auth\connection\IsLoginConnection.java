package com.dmm.app.auth.connection;

import android.content.Context;
import com.android.volley.Response.ErrorListener;
import com.dmm.app.connection.ApiConnection;
import com.dmm.app.connection.DmmListener;
import java.util.Map;

public class IsLoginConnection<T> extends ApiConnection<T> {
    public static final String API_KEY_EXPLOITID = "exploit_id";
    public static final String API_KEY_SECUREID = "secure_id";
    public static final String API_VAL_MESSAGE = "Auth.IsLoginSecure";
    private static final String[] REQUERYED_PARAM_NAMES = new String[]{"exploit_id", API_KEY_SECUREID};

    public IsLoginConnection(Context context, Map<String, String> params, Class<T> entity, DmmListener<T> listener) {
        super(context, API_VAL_MESSAGE, params, entity, listener);
        setRequiredParamNames(REQUERYED_PARAM_NAMES);
    }

    public IsLoginConnection(Context context, Map<String, String> params, Class<T> entity, DmmListener<T> listener, ErrorListener errorListener) {
        super(context, API_VAL_MESSAGE, params, entity, listener, errorListener);
        setRequiredParamNames(REQUERYED_PARAM_NAMES);
    }
}
