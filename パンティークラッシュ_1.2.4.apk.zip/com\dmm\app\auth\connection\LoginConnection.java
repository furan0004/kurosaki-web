package com.dmm.app.auth.connection;

import android.content.Context;
import com.android.volley.Response.ErrorListener;
import com.dmm.app.connection.ApiConnection;
import com.dmm.app.connection.DmmListener;
import java.util.Map;

public class LoginConnection<T> extends ApiConnection<T> {
    public static final String API_KEY_EMAIL = "email";
    public static final String API_KEY_HTTPACCEPT = "httpAcceptLanguage";
    public static final String API_KEY_IS_ADULT = "isAdult";
    public static final String API_KEY_JP_STATUS = "jpStatus";
    public static final String API_KEY_KIND = "loginKind";
    public static final String API_KEY_LOGINID = "loginId";
    public static final String API_KEY_PASS = "password";
    public static final String API_KEY_REMOTEADDR = "remoteAddress";
    public static final String API_KEY_USERAGENT = "userAgent";
    public static final String API_KEY_UUID = "appTerminalId";
    public static final String API_VAL_MESSAGE = "Auth.LoginSmartPhone";
    public static final String HTTP_ACCEPT_LANG = "ja";
    public static final String KIND_PORTAL = "dmmportal";
    private static final String[] REQUERYED_PARAM_NAMES = new String[]{"password", "loginKind", "userAgent", "httpAcceptLanguage"};
    public static final String USER_AGENT = "PORTALAPP";

    public LoginConnection(Context context, Map<String, String> params, Class<T> entity, DmmListener<T> listener) {
        super(context, "Auth.LoginSmartPhone", params, entity, listener);
        setRequiredParamNames(REQUERYED_PARAM_NAMES);
    }

    public LoginConnection(Context context, Map<String, String> params, Class<T> entity, DmmListener<T> listener, ErrorListener errorListener) {
        super(context, "Auth.LoginSmartPhone", params, entity, listener, errorListener);
        setRequiredParamNames(REQUERYED_PARAM_NAMES);
    }
}
