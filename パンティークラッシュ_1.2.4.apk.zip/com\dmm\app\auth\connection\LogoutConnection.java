package com.dmm.app.auth.connection;

import android.content.Context;
import com.android.volley.Response.ErrorListener;
import com.dmm.app.connection.ApiConnection;
import com.dmm.app.connection.DmmListener;
import java.util.Map;

public class LogoutConnection<T> extends ApiConnection<T> {
    public static final String API_KEY_APP_TOKEN = "autoLoginAppToken";
    public static final String API_KEY_EXPLOITID = "exploit_id";
    public static final String API_KEY_IS_INTERFACE = "is_interface";
    public static final String API_VAL_MESSAGE = "Auth.Logout";
    public static final String INTERFACE = "true";
    private static final String[] REQUERYED_PARAM_NAMES = new String[]{"exploit_id", "autoLoginAppToken"};

    public LogoutConnection(Context context, Map<String, String> params, Class<T> entity, DmmListener<T> listener) {
        super(context, API_VAL_MESSAGE, params, entity, listener);
        setRequiredParamNames(REQUERYED_PARAM_NAMES);
    }

    public LogoutConnection(Context context, Map<String, String> params, Class<T> entity, DmmListener<T> listener, ErrorListener errorListener) {
        super(context, API_VAL_MESSAGE, params, entity, listener, errorListener);
        setRequiredParamNames(REQUERYED_PARAM_NAMES);
    }
}
