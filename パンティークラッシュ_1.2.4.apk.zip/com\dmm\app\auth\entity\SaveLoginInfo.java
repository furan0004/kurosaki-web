package com.dmm.app.auth.entity;

import android.content.Context;
import com.dmm.app.base.Define;

public class SaveLoginInfo {
    private static final String PREF_NAME = "SaveLoginInfo";
    private Context context;

    public SaveLoginInfo(Context context) {
        this.context = context;
    }

    public String getSaveLoginId() {
        return this.context.getSharedPreferences(PREF_NAME, 0).getString("saveLoginId", "");
    }

    public void setSaveLoginId(String saveLoginId) {
        this.context.getSharedPreferences(PREF_NAME, 0).edit().putString("saveLoginId", saveLoginId).commit();
    }

    public String getSavePasswdHash() {
        return this.context.getSharedPreferences(PREF_NAME, 0).getString(Define.AUTH_KEY_SAVED_PASSWDHASH, "");
    }

    public void setSavePasswdHash(String savepass) {
        this.context.getSharedPreferences(PREF_NAME, 0).edit().putString(Define.AUTH_KEY_SAVED_PASSWDHASH, savepass).commit();
    }

    public String getId() {
        return this.context.getSharedPreferences(PREF_NAME, 0).getString("saveId", "");
    }

    public void setId(String id) {
        this.context.getSharedPreferences(PREF_NAME, 0).edit().putString("saveId", id).commit();
    }

    public boolean getSaveLoginIdCheck() {
        return this.context.getSharedPreferences(PREF_NAME, 0).getBoolean("saveLoginIdChecked", false);
    }

    public void setSaveLoginIdCheck(boolean chk) {
        this.context.getSharedPreferences(PREF_NAME, 0).edit().putBoolean("saveLoginIdChecked", chk).commit();
    }

    public boolean getSavePasswdIdCheck() {
        return this.context.getSharedPreferences(PREF_NAME, 0).getBoolean(Define.AUTH_KEY_SAVED_PASSWDHASH_CHECKED, false);
    }

    public void setSavePasswdCheck(boolean chk) {
        this.context.getSharedPreferences(PREF_NAME, 0).edit().putBoolean(Define.AUTH_KEY_SAVED_PASSWDHASH_CHECKED, chk).commit();
    }
}
