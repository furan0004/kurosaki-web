package com.dmm.app.auth.entity;

import android.content.Context;
import android.content.SharedPreferences;
import com.dmm.app.auth.entity.connection.LoginResult;
import com.dmm.app.authmanager.entity.connection.AuthLoginAutoEntity;
import java.util.UUID;

public class UserInfo {
    private Context context;
    private UserInfoEntity userInfoEntity = new UserInfoEntity();

    public class UserInfoEntity {
        private static final String APPLOGINTOKEN_KEY = "appLoginToken";
        private static final String EMPTY_STRING = "";
        private static final String LOGINDEVICE_KEY = "loginDevice";
        private static final String MEMBER_KEY = "memberId";
        private static final int PREF_MODE = 0;
        private static final String PREF_NAME = "DmmUserInfo";
        private static final String SECUREID_KEY = "secureId";
        private static final String UNIQUEID_KEY = "uniqueId";
        private static final String UUID_KEY = "deviceUUID";

        public String getUniqueId() {
            return UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).getString(UNIQUEID_KEY, "");
        }

        public void setUniqueId(String uniqueId) {
            UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).edit().putString(UNIQUEID_KEY, uniqueId).commit();
        }

        public String getMemberId() {
            return UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).getString(MEMBER_KEY, "");
        }

        public void setMemberId(String memberId) {
            UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).edit().putString(MEMBER_KEY, memberId).commit();
        }

        public String getSecureId() {
            return UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).getString(SECUREID_KEY, "");
        }

        public void setSecureId(String secureId) {
            UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).edit().putString(SECUREID_KEY, secureId).commit();
        }

        public String getAppLoginToken() {
            return UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).getString(APPLOGINTOKEN_KEY, "");
        }

        public void setAppLoginToken(String appToken) {
            UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).edit().putString(APPLOGINTOKEN_KEY, appToken).commit();
        }

        public String getLoginDevice() {
            return UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).getString(LOGINDEVICE_KEY, "");
        }

        public void setLoginDevice(String loginDevice) {
            UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).edit().putString(LOGINDEVICE_KEY, loginDevice).commit();
        }

        public String generateUuid() {
            SharedPreferences dmmPref = UserInfo.this.context.getSharedPreferences(PREF_NAME, 0);
            String uuid = dmmPref.getString("deviceUUID", "");
            if (!"".equals(uuid)) {
                return uuid;
            }
            uuid = UUID.randomUUID().toString();
            dmmPref.edit().putString("deviceUUID", uuid).commit();
            return uuid;
        }

        public void clearUserInfo() {
            SharedPreferences dmmPref = UserInfo.this.context.getSharedPreferences(PREF_NAME, 0);
            dmmPref.edit().remove(UNIQUEID_KEY).commit();
            dmmPref.edit().remove(MEMBER_KEY).commit();
            dmmPref.edit().remove(SECUREID_KEY).commit();
            dmmPref.edit().remove(LOGINDEVICE_KEY).commit();
            dmmPref.edit().remove("deviceUUID").commit();
        }

        public void clearAppToken() {
            UserInfo.this.context.getSharedPreferences(PREF_NAME, 0).edit().remove(APPLOGINTOKEN_KEY).commit();
        }
    }

    public UserInfo(Context context) {
        this.context = context;
    }

    public void saveUserInfo(LoginResult loginResult) {
        this.userInfoEntity.setMemberId(loginResult.getData().getMemberId());
        this.userInfoEntity.setUniqueId(loginResult.getData().getUniqueId());
        this.userInfoEntity.setSecureId(loginResult.getData().getSecureId());
        this.userInfoEntity.setAppLoginToken(loginResult.getData().getAppToken());
        this.userInfoEntity.setLoginDevice(loginResult.getData().getLoginDevice());
    }

    public void saveUserInfo(AuthLoginAutoEntity autoLoginAutoEntry) {
        this.userInfoEntity.setMemberId(autoLoginAutoEntry.getData().getMemberId());
        this.userInfoEntity.setUniqueId(autoLoginAutoEntry.getData().getUniqueId());
        this.userInfoEntity.setSecureId(autoLoginAutoEntry.getData().getSecureId());
    }

    public UserInfoEntity getUserInfoEntity() {
        return this.userInfoEntity;
    }

    public String getUniqueId() {
        return this.userInfoEntity.getUniqueId();
    }

    public String getMemberId() {
        return this.userInfoEntity.getMemberId();
    }

    public String getSecureId() {
        return this.userInfoEntity.getSecureId();
    }

    public String getAppLoginToken() {
        return this.userInfoEntity.getAppLoginToken();
    }

    public String getLoginDevice() {
        return this.userInfoEntity.getLoginDevice();
    }

    public String generateUuid() {
        return this.userInfoEntity.generateUuid();
    }

    public void clearUserInfo() {
        this.userInfoEntity.clearUserInfo();
    }

    public void clearAppToken() {
        this.userInfoEntity.clearAppToken();
    }
}
