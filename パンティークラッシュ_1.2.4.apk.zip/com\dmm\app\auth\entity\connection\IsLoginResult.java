package com.dmm.app.auth.entity.connection;

import com.dmm.app.connection.ApiResult;
import com.google.gson.annotations.SerializedName;

public class IsLoginResult extends ApiResult {
    private Data data;

    public class Data {
        @SerializedName("is_login")
        private boolean isLogin;

        public void setIsLogin(boolean isLogin) {
            this.isLogin = isLogin;
        }

        public boolean getIsLogin() {
            return this.isLogin;
        }
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Data getData() {
        return this.data;
    }
}
