package com.dmm.app.auth.entity.connection;

import com.dmm.app.connection.ApiResult;

public class LoginResult extends ApiResult {
    private Data data;

    public class Data {
        private String appToken;
        private String autoLoginToken;
        private String loginDevice;
        private String memberId;
        private String secureId;
        private String sendMailFlg;
        private String uniqueId;
        private String url;

        public String getMemberId() {
            return this.memberId;
        }

        public void setMemberId(String memberId) {
            this.memberId = memberId;
        }

        public String getUniqueId() {
            return this.uniqueId;
        }

        public void setUniqueId(String uniqueId) {
            this.uniqueId = uniqueId;
        }

        public String getSecureId() {
            return this.secureId;
        }

        public void setSecureId(String secureId) {
            this.secureId = secureId;
        }

        public String getAutoLoginToken() {
            return this.autoLoginToken;
        }

        public void setAutoLoginToken(String autoLoginToken) {
            this.autoLoginToken = autoLoginToken;
        }

        public String getSendMailFlg() {
            return this.sendMailFlg;
        }

        public void setSendMailFlg(String sendMailFlg) {
            this.sendMailFlg = sendMailFlg;
        }

        public String getLoginDevice() {
            return this.loginDevice;
        }

        public void setLoginDevice(String loginDevice) {
            this.loginDevice = loginDevice;
        }

        public String getAppToken() {
            return this.appToken;
        }

        public void setAppToken(String appToken) {
            this.appToken = appToken;
        }

        public String getUrl() {
            return this.url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }

    public Data getData() {
        return this.data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
