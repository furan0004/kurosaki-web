package com.dmm.app.auth.entity.connection;

import com.dmm.app.connection.ApiResult;

public class LogoutResult extends ApiResult {
    private Data data;

    public class Data {
        private boolean result;

        public boolean getResult() {
            return this.result;
        }

        public void setResult(boolean result) {
            this.result = result;
        }
    }

    public Data getData() {
        return this.data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
