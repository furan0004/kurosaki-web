package com.dmm.app.auth.util;

import android.content.Context;
import android.os.Build;
import android.os.Build.VERSION;
import com.dmm.app.base.Define;
import com.dmm.app.common.DmmCommonUtil;
import com.dmm.app.common.DmmDefine;
import com.dmm.app.util.PackageUtil;
import java.util.Locale;

public final class AuthUtil {
    private static final String APPSTORE = "DMMAPPSTORE";
    public static final int APP_TYPE_APPSTORE = 2;
    public static final int APP_TYPE_DEFAULT = 0;
    public static final int APP_TYPE_MOVIE_PLAYER = 1;
    public static final int APP_TYPE_SKE = 3;
    private static final String DMM = "DMMAPP";
    private static final String NO_PARAM = "-";
    private static final String PLAYER = "DMMPLAY";
    private static final String SKE = "DMMSKE";

    private AuthUtil() {
    }

    private static String createUserAgent(int appType, String appVersionName, String deviceOs, String lang, String productName) {
        String app;
        String appVersion;
        String osVersion;
        String locale;
        String product;
        if (appType == 1) {
            app = PLAYER;
        } else if (appType == 2) {
            app = APPSTORE;
        } else if (appType == 3) {
            app = PLAYER;
        } else {
            app = DMM;
        }
        if (DmmCommonUtil.isEmpty(appVersionName)) {
            appVersion = NO_PARAM;
        } else {
            appVersion = appVersionName;
        }
        if (DmmCommonUtil.isEmpty(deviceOs)) {
            osVersion = NO_PARAM;
        } else {
            osVersion = deviceOs;
        }
        if (DmmCommonUtil.isEmpty(lang)) {
            locale = NO_PARAM;
        } else {
            locale = lang;
        }
        if (DmmCommonUtil.isEmpty(productName)) {
            product = NO_PARAM;
        } else {
            product = productName;
        }
        return String.format("%s %s (ANDROID; %s; %s; %s;)", new Object[]{app, appVersion, osVersion, locale, product});
    }

    public static String getApiUserAgent(Context context, int appType) {
        String appVersionName;
        String locale;
        if (context == null) {
            appVersionName = null;
        } else {
            appVersionName = PackageUtil.getCurrentVersionName(context.getPackageManager(), context.getPackageName());
        }
        String osVersion = VERSION.RELEASE;
        String productName = Build.DEVICE;
        if (Locale.getDefault() != null) {
            locale = Locale.getDefault().toString();
        } else {
            locale = null;
        }
        return createUserAgent(appType, appVersionName, osVersion, locale, productName);
    }

    public static String getLoginKind(int appCode) {
        switch (appCode) {
            case 1:
                return Define.LOGINKIND_MOVIEPLAYER;
            case 2:
                return Define.LOGINKIND_APPSTORE;
            case 3:
                return Define.LOGINKIND_MOVIEPLAYER;
            default:
                return null;
        }
    }

    public static int getAppType(String packageName) {
        if (DmmDefine.MOVIEAPP_PACKAGE.equals(packageName)) {
            return 1;
        }
        if ("com.dmm.app.store".equals(packageName)) {
            return 2;
        }
        if (DmmDefine.SKE_PACKAGE.equals(packageName)) {
            return 1;
        }
        return 0;
    }
}
