package com.dmm.app.authmanager.entity.connection;

import com.dmm.app.connection.ApiResult;

public class AuthIsLoginEntity extends ApiResult {
    private Data data;

    public class Data {
        private boolean flag;

        public void setFlag(boolean flag) {
            this.flag = flag;
        }

        public boolean isFlag() {
            return this.flag;
        }
    }

    public Data getData() {
        return this.data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
