package com.dmm.app.authmanager.entity.connection;

import com.dmm.app.connection.ApiResult;

public class AuthLoginAutoEntity extends ApiResult {
    private Data data;

    public class Data {
        private String memberId;
        private String secureId;
        private String uniqueId;

        public void setMemberId(String memberId) {
            this.memberId = memberId;
        }

        public String getMemberId() {
            return this.memberId;
        }

        public void setUniqueId(String uniqueId) {
            this.uniqueId = uniqueId;
        }

        public String getUniqueId() {
            return this.uniqueId;
        }

        public void setSecureId(String secureId) {
            this.secureId = secureId;
        }

        public String getSecureId() {
            return this.secureId;
        }
    }

    public Data getData() {
        return this.data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
