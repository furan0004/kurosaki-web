package com.dmm.app.base;

public final class Define {
    public static final String AKB48_SERVICEY_CODE = "akb";
    public static final String ANIM_BOTTOM = "bottom";
    public static final int ANIM_DURATION = 1000;
    public static final String ANIM_LEFT = "left";
    public static final String ANIM_RIGHT = "right";
    public static final String ANIM_TOP = "top";
    public static final String AUTH_KEY_SAVED_ID = "saveId";
    public static final String AUTH_KEY_SAVED_LOGINID = "saveLoginId";
    public static final String AUTH_KEY_SAVED_LOGINID_CHECKED = "saveLoginIdChecked";
    public static final String AUTH_KEY_SAVED_PASSWDHASH = "savePasswdHash";
    public static final String AUTH_KEY_SAVED_PASSWDHASH_CHECKED = "savePasswdHashChecked";
    public static final String AUTH_KEY_UUID = "deviceUUID";
    public static final String EXTRA_KEY_INI_NAME = "extraKeyIniPageName";
    public static final String EXTRA_KEY_INI_URL = "extraKeyIniPageUrl";
    public static final String EXTRA_KEY_IS_LOGO_R18 = "extraKeyIsLogoR18";
    public static final String GROUP_STR = "\nグループ";
    public static final String IS_FIRST_START_KEY = "IsFirstStartKey";
    public static final String KEY_CURRENT_PASSCODE = "currentPassCode";
    public static final String KEY_PASSCODE_CANCEL_MSG = "passcodeCancelMsg";
    public static final String KEY_PASSCODE_DESCRIPTION_MSG = "passcodeCancelMsg";
    public static final String KEY_PASSCODE_SETTING = "settingPassCodeIsSettingFlag";
    public static final String LABEL_OFF = "OFF";
    public static final String LABEL_ON = "ON";
    public static final String LOGINKIND_APPSTORE = "and_dmmappstore";
    public static final String LOGINKIND_MOVIEPLAYER = "and_dmmplayer";
    public static final String LOGIN_MAIL_ADRESS = "login_mail_adress";
    public static final String LOGIN_PASS = "login_password";
    public static final String LOGIN_R18 = "extraLoginToR18";
    public static final int PASSLOCK_OFF_CD = 0;
    public static final int PASSLOCK_ON_CD = 1;
    public static final String PASSWORD_REMINDER_FMT = "https://www.%s/my/-/passwordreminder/";
    public static final String PATH_PASSCODE_FILE_NAME = "UserData";
    public static final int REQ_CODE_INIPAGE_SETTING = 10;
    public static final int REQ_CODE_PASSCODE_SETTING = 20;
    public static final String SETTING_NONE = "未設定";
    public static final String TOPNAVI_TAG_APPSTORE = "digi-pcgameapp";
    public static final String URLPN_AGE = "http://sp.dmm.co.jp/age/index";
    public static final String URLPTN_DOMAIN_COJP = "dmm.co.jp";
    public static final String URLPTN_DOMAIN_COM = "dmm.com";
    public static final String URL_COJP = "http://www.dmm.co.jp/";
    public static final String URL_COM = "http://www.dmm.com/";
    public static final String URL_DETAIL_SAMPLE_IMAGE_LIST = "thumbnail/index/";
    public static final String URL_ENCOUNTER_LITE = "lite.yyc.dmm.co.jp";
    public static final String URL_ENCOUNTER_MAX = "max.dmm.co.jp";
    public static final String URL_ENCOUNTER_SP = "sp.194964.dmm.co.jp";
    public static final String URL_HOST_IMAGE = "pics";
    public static final Integer USER_ID_LENGTH = Integer.valueOf(8);

    private Define() {
    }
}
