package com.dmm.app.base;

public final class Ids {
    public static final int DIALOG_ANNOUNCE = 60;
    public static final int DIALOG_API_PROGRESS = 11;
    public static final int DIALOG_DELETE_CONFIRM = 20;
    public static final int DIALOG_DOWNLOAD_CANCEL = 40;
    public static final int DIALOG_ID_ALERT = 160;
    public static final int DIALOG_ID_ALERT_FINISH = 170;
    public static final int DIALOG_ID_AUTH = 150;
    public static final int DIALOG_ID_CONFIRM_LOGOUT = 130;
    public static final int DIALOG_ID_IMAGE = 180;
    public static final int DIALOG_ID_LOGIN = 110;
    public static final int DIALOG_ID_LOGIN_BUY = 120;
    public static final int DIALOG_ID_NO_CREDIT = 190;
    public static final int DIALOG_ID_NO_DEPOSIT = 200;
    public static final int DIALOG_ID_UPDATE = 140;
    public static final int DIALOG_MARKET_LOADING = 100;
    public static final int DIALOG_MENU_ITEM_HELP = 210;
    public static final int DIALOG_OFFLINE = 50;
    public static final int DIALOG_PROGRESS = 10;
    public static final int DIALOG_UPDATE_COMPLETE = 30;

    private Ids() {
    }
}
