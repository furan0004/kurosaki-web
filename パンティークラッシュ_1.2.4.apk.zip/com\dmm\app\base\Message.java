package com.dmm.app.base;

public final class Message {
    public static final String ERR_APP_START = "DMMの起動をキャンセルしました";
    public static final String ERR_CONTENTFILE_NOT_FOUND = "コンテンツが見つかりません。\nファイル管理から対象コンテンツ情報を削除して再度お試しください。";
    public static final String ERR_DOWNLOAD_FILEIO = "システムエラーが発生しました。(A022)";
    public static final String ERR_DOWNLOAD_GENERIC = "システムエラーが発生しました。(A033)";
    public static final String ERR_DOWNLOAD_NETWORK = "通信エラーが発生しました。(A023)";
    public static final String ERR_DOWNLOAD_QUEUEDEPRECATED = "既にダウンロード中です。(A024)";
    public static final String ERR_DOWNLOAD_TMPFILENAME = "システムエラーが発生しました。(A022)";
    public static final String ERR_PASSFILE_SAVE_FAILED = "ファイルの保存に失敗しました。";
    public static final String MSG_FILE_SAVE = "設定を保存しました。";
    public static final String MSG_PASSCODE_CHECK_FAIL = "パスコードが違います。";
    public static final String MSG_PASSCODE_ONE_MORE = "確認の為もう一度入力してください。";

    private Message() {
    }
}
