package com.dmm.app.common;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
