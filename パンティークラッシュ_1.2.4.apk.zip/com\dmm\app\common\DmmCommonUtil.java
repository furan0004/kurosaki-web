package com.dmm.app.common;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.os.Build.VERSION;
import android.os.Environment;
import android.util.Base64;
import com.dmm.app.auth.entity.UserInfo;
import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;

public final class DmmCommonUtil {
    private DmmCommonUtil() {
        throw new UnsupportedOperationException();
    }

    public static boolean isEmpty(String value) {
        if (value == null || "".equals(value) || "null".equals(value)) {
            return true;
        }
        return false;
    }

    public static boolean isInteger(String value) {
        if (isEmpty(value)) {
            return false;
        }
        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isDateString(String value) {
        if (isEmpty(value)) {
            return false;
        }
        String replacedStr = value.replaceAll("-", "/");
        DateFormat format = DateFormat.getDateInstance();
        format.setLenient(false);
        try {
            format.parse(replacedStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String splitStr(String target, int startIndex, int limit, String addMark) {
        if (target == null || target.equals("") || target.length() <= limit || limit + startIndex > target.length()) {
            return target;
        }
        if (addMark == null) {
            return target.substring(startIndex, limit + startIndex);
        }
        return target.substring(startIndex, limit + startIndex).concat(addMark);
    }

    public static String stripTags(String value) {
        if (isEmpty(value)) {
            return value;
        }
        return stripDmmTags(stripHtmlTags(value.replaceAll("<><><>", "\n\n").replaceAll("<br><br><br>", "\n\n").replaceAll("<br/><br/><br/>", "\n\n").replaceAll("<br /><br /><br />", "\n\n").replaceAll("<>", "\n").replaceAll("<br>", "\n").replaceAll("<br/>", "\n").replaceAll("<br />", "\n").replaceAll("<BR>", "\n").replaceAll("<BR/>", "\n").replaceAll("<BR />", "\n")));
    }

    public static String stripHtmlTags(String value) {
        return isEmpty(value) ? value : value.replaceAll("<.+?>", "").replaceAll("&lt;.+?&gt;", "");
    }

    public static String stripDmmTags(String value) {
        if (isEmpty(value)) {
            return value;
        }
        return value.replaceAll("\\{\\{", "").replaceAll("\\}\\}", "").replaceAll("\\{link.+?\\}", "").replaceAll("\\{image.+?\\}", "").replaceAll("/\\}", "").replaceAll("\\{.+?\\}", "").replaceAll("\\{/", "");
    }

    public static int convertBoolToInt(boolean bool) {
        if (bool) {
            return 1;
        }
        return 0;
    }

    public static boolean convertIntToBool(int i) {
        if (i > 0) {
            return true;
        }
        return false;
    }

    public static boolean isUrl(String url) {
        if (!isEmpty(url) && Pattern.compile("^(http|https?|ftp|file)", 2).matcher(url).find()) {
            return true;
        }
        return false;
    }

    public static String getSdFilePath() {
        return Environment.getExternalStorageDirectory().getPath();
    }

    public static Bitmap convertByte2Bitmap(byte[] blob) {
        if (blob == null) {
            return null;
        }
        return BitmapFactory.decodeByteArray(blob, 0, blob.length);
    }

    public static byte[] convertBitmap2Byte(Bitmap bitmap) {
        if (bitmap == null) {
            return null;
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.JPEG, 100, baos);
        return baos.toByteArray();
    }

    public static String base64UrlEncode(String url) {
        return URLEncoder.encode(Base64.encodeToString(url.getBytes(), 0));
    }

    public static String addDmmUrlGetParameters(String url, Map<String, String> params) {
        String dmmUrl = "";
        String addParamString = "";
        for (Entry<String, String> param : params.entrySet()) {
            addParamString = new StringBuilder(String.valueOf(addParamString)).append("/").append((String) param.getKey()).append("=").append((String) param.getValue()).toString();
        }
        if (url.indexOf("/=/") != -1) {
            return new StringBuilder(String.valueOf(url)).append(addParamString).toString();
        }
        if (url.endsWith("/")) {
            return new StringBuilder(String.valueOf(url)).append("=").append(addParamString).toString();
        }
        return new StringBuilder(String.valueOf(url)).append("/=").append(addParamString).toString();
    }

    public static String getUserAgent(String appName, Context context) {
        String userAgent = "";
        String userAgentFormat = "%s (%d, %s) API Level:%d PORTALAPP Android";
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            int appVersionCode = packageInfo.versionCode;
            String appVersionName = packageInfo.versionName;
            int buildLevel = VERSION.SDK_INT;
            userAgent = String.format(userAgentFormat, new Object[]{appName, Integer.valueOf(appVersionCode), appVersionName, Integer.valueOf(buildLevel)});
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
        return userAgent;
    }

    public static String getString(Context context, int resId) {
        return context.getResources().getString(resId);
    }

    public static boolean isLogin(Context context) {
        return !isEmpty(new UserInfo(context).getUniqueId());
    }
}
