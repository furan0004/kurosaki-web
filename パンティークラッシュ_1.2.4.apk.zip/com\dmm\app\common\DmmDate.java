package com.dmm.app.common;

import java.util.Calendar;
import java.util.regex.Pattern;

public final class DmmDate {
    private static final String DATEPOS = " ";
    private static final String DAYPOS = "-";
    private static final String TMIEPOS = ":";

    private DmmDate() {
    }

    public static String replaceDayFormat(String targ, int type) {
        String ret = null;
        if (targ == null || targ.equals("")) {
            return null;
        }
        String pos;
        switch (type) {
            case 1:
                pos = DAYPOS;
                if (chkFormat(targ, pos).booleanValue()) {
                    ret = targ.replaceAll(pos, "/");
                    break;
                }
                break;
            case 2:
                pos = DAYPOS;
                if (chkFormat(targ, pos).booleanValue()) {
                    String ymdHis = targ.replaceAll(pos, "/");
                    if (ymdHis.indexOf(DATEPOS) < 0) {
                        ret = ymdHis;
                        break;
                    }
                    ret = ymdHis.split(DATEPOS)[0];
                    break;
                }
                break;
        }
        return ret;
    }

    public static String getDateString(String value) {
        if (value == null || value.equals("") || value.length() <= 5) {
            return null;
        }
        if (!Pattern.compile("[0-9]{4}[^0-9]+[0-9]{1,2}[^0-9]+[0-9]{1,2}").matcher(value).find()) {
            return null;
        }
        String[] result = value.split(value.substring(4, 5));
        if (result[2].length() >= 2) {
            String tmp = result[2].substring(1, 2);
            if (Pattern.compile("[0-9]+").matcher(tmp).find()) {
                result[2] = new StringBuilder(String.valueOf(result[2].substring(0, 1))).append(tmp).toString();
            } else {
                result[2] = result[2].substring(0, 1);
            }
        }
        return String.format("%s%s%s%s%s", new Object[]{result[0], pos, result[1], pos, result[2]}).toString();
    }

    public static Boolean chkFormat(String target, String pos) {
        if (target == null || target.equals("")) {
            return Boolean.valueOf(false);
        }
        String posStr;
        if (pos == null || pos.equals("")) {
            posStr = "/";
        } else {
            posStr = pos;
        }
        if (Pattern.compile(String.format("[0-9]{4}%s[0-9]{1,2}%s[0-9]{1,2}", new Object[]{posStr, posStr})).matcher(target).find()) {
            return Boolean.valueOf(true);
        }
        return Boolean.valueOf(false);
    }

    public static Calendar convertDate(String targDate) {
        String[] purchStr = targDate.split(DATEPOS);
        String[] purchaseDateStr = purchStr[0].split(DAYPOS);
        int y = Integer.parseInt(purchaseDateStr[0]);
        int m = Integer.parseInt(purchaseDateStr[1]);
        int d = Integer.parseInt(purchaseDateStr[2]);
        houer = new int[3];
        String[] timeStr = purchStr[1].split(TMIEPOS);
        houer[0] = Integer.parseInt(timeStr[0]);
        houer[1] = Integer.parseInt(timeStr[1]);
        houer[2] = Integer.parseInt(timeStr[2]);
        Calendar calendarExp = Calendar.getInstance();
        calendarExp.set(y, m - 1, d, houer[0], houer[1], houer[2]);
        return calendarExp;
    }

    public static boolean isEnableExpire(String begin, String end, Calendar currentTime, boolean phpFlg) {
        if (currentTime == null) {
            return false;
        }
        Calendar calBegin;
        Calendar calEnd;
        if (phpFlg) {
            try {
                if (DmmCommonUtil.isEmpty(begin)) {
                    calBegin = currentTime;
                } else {
                    calBegin = convertDate(begin);
                }
                if (DmmCommonUtil.isEmpty(end) && phpFlg) {
                    calEnd = currentTime;
                } else {
                    calEnd = convertDate(end);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        } else if (DmmCommonUtil.isEmpty(begin) || DmmCommonUtil.isEmpty(end)) {
            return false;
        } else {
            calBegin = convertDate(begin);
            calEnd = convertDate(end);
        }
        if (calBegin.before(currentTime) && currentTime.before(calEnd)) {
            return true;
        }
        return false;
    }
}
