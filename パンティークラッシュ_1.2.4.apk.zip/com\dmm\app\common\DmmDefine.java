package com.dmm.app.common;

public final class DmmDefine {
    public static final String AUTH_PREF_NAME = "DmmAuthLibrary";
    public static final String EMPTY_STR = "";
    public static final String EXTRA_KEY_AUTO_LOGIN_TOKEN = "autoLoginTokenFromPortalApp";
    public static final String EXTRA_KEY_CONTENT_ID = "extraContentId";
    public static final String EXTRA_KEY_ERROR_MSG = "loginErrorMessageFromPortalApp";
    public static final String EXTRA_KEY_EXPLOIT_ID = "exploitIdFromPortalApp";
    public static final String EXTRA_KEY_SECURE_ID = "secureIdFromPortalApp";
    public static final String EXTRA_LOGIN_APP_CD = "loginAppCode";
    public static final String EXTRA_LOGIN_REFERER_USER_RESULT = "loginActivityRefererUserOnResult";
    public static final String EXTRA_LOGIN_REGIST_TAB_VISIBILITY = "loginActivityRegistTabVisible";
    public static final String KEY_GAME_ID = "extraGameId";
    public static final String KEY_HASH = "extraUsersHash";
    public static final String KEY_INPUT_LOGINID = "inputId";
    public static final String KEY_INT_SESSION = "extraIntSession";
    public static final String KEY_LOGIN_STATUS = "extraLoginStatus";
    public static final String KEY_MAKER_ID = "extraMakerId";
    public static final String KEY_PACKAGE = "extraPackageName";
    public static final String KEY_TOKEN = "extraAuthToken";
    public static final String LOGIN_R18 = "extraLoginToR18";
    public static final String MEMBER_REGIST = "extraMemberRegistFlag";
    public static final String MOVIEAPP_PACKAGE = "com.dmm.app.vplayer";
    public static final int NOTIFICATION_ID_APP_UPDATE = 1;
    public static final String PLAY_MOVIE_FILE_DIR = "play_movie_file_dir";
    public static final String PLAY_MOVIE_FILE_NAME = "play_movie_file_name";
    public static final int REQ_CODE_GAME_AUTH_LOGIN = 20;
    public static final int REQ_CODE_SETTING = 0;
    public static final String SKE_PACKAGE = "com.dmm.ske48app";
    public static final String STOREAPP_PACKAGE = "com.dmm.app.store";
    public static final String URL_PORTAL = "http://www.dmm.co.jp/app/-/android-dmmportal/appmarket/";
    public static final String URL_STOREAPP_DOWNLOAD = "http://www.dmm.co.jp/app/-/appstore/download/";

    private DmmDefine() {
    }
}
