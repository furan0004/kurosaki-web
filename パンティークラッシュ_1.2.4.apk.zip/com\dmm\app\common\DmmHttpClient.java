package com.dmm.app.common;

import java.security.KeyStore;
import oauth.signpost.OAuth;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

public class DmmHttpClient {
    private DefaultHttpClient httpClient = new DefaultHttpClient();
    private HttpContext httpContext = new BasicHttpContext();
    private final int sslPort = 443;

    DmmHttpClient() throws Exception {
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
        trustStore.load(null, null);
        DmmSSLSocketFactory sf = new DmmSSLSocketFactory(trustStore);
        sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        this.httpClient.getConnectionManager().getSchemeRegistry().register(new Scheme("https", sf, 443));
        this.httpContext.setAttribute("http.protocol.version", HttpVersion.HTTP_1_1);
        this.httpContext.setAttribute("http.protocol.expect-continue", Boolean.valueOf(false));
        this.httpContext.setAttribute("http.protocol.content-charset", OAuth.ENCODING);
    }

    public HttpClient getClient() {
        return this.httpClient;
    }

    public void connectCancel() {
        this.httpClient.getConnectionManager().closeExpiredConnections();
        this.httpClient.getConnectionManager().shutdown();
    }
}
