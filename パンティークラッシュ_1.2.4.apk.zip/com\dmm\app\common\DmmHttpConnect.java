package com.dmm.app.common;

import com.dmm.asdk.core.CoreSetting;
import java.util.ArrayList;
import oauth.signpost.OAuth;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class DmmHttpConnect {
    public static final String HEADER = "BookViewer";
    private static final int PORT = 80;
    private static final int PORT_SSL = 443;
    public static final String TAG = "DmmHttpConnect";
    public static final String UA = "Android";
    private DefaultHttpClient client;
    private String connectUrl = null;
    private String response = null;

    public DmmHttpConnect(String url) {
        this.connectUrl = url;
    }

    public void connect(ArrayList<NameValuePair> params) throws Exception {
        HttpPost httpPost = new HttpPost(this.connectUrl);
        httpPost.addHeader(CoreSetting.CUSTOM_HEADER_SP_KEY, HEADER);
        httpPost.setEntity(new UrlEncodedFormEntity(params, OAuth.ENCODING));
        this.client = (DefaultHttpClient) new DmmHttpClient().getClient();
        Credentials credentials = new UsernamePasswordCredentials("dmm", "ldmm1");
        this.client.getCredentialsProvider().setCredentials(new AuthScope("www.dmm.com", PORT), credentials);
        this.client.getCredentialsProvider().setCredentials(new AuthScope("www.dmm.com", PORT_SSL), credentials);
        this.client.getParams().setParameter("http.useragent", "Android");
        HttpEntity entity = this.client.execute(httpPost).getEntity();
        this.response = EntityUtils.toString(entity, OAuth.ENCODING);
        entity.consumeContent();
        this.client.getConnectionManager().shutdown();
    }

    public String getResponse() {
        return this.response;
    }
}
