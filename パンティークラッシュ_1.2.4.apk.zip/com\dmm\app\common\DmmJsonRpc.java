package com.dmm.app.common;

import com.dmm.app.auth.connection.LogoutConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DmmJsonRpc extends DmmHttpConnect {
    public static final String JSON_URL = "http://www.dmm.com/service/-/json?method=Android";
    private DmmJsonRpcError error = null;
    private JSONObject json;

    public DmmJsonRpc() {
        super(JSON_URL);
    }

    public boolean request(ArrayList<NameValuePair> requestParams) {
        try {
            connect(requestParams);
            return checkError();
        } catch (Exception e) {
            e.printStackTrace();
            this.error = new DmmJsonRpcError();
            return false;
        }
    }

    private boolean checkError() throws Exception {
        this.error = null;
        this.json = new JSONObject(getResponse());
        if (!this.json.has("event")) {
            this.error = new DmmJsonRpcError();
            return false;
        } else if (this.json.getString("event").equals(LogoutConnection.INTERFACE)) {
            return true;
        } else {
            this.error = new DmmJsonRpcError();
            int errCd = Integer.parseInt(this.json.getString("error"));
            try {
                this.error.checkError(errCd, this.json.getJSONObject("data").getString("message"));
                return false;
            } catch (Exception e) {
                this.error.checkError(errCd, null);
                return false;
            }
        }
    }

    private Object parseObject(String key, JSONObject jsonObj) {
        try {
            JSONObject jsonObject;
            Iterator<?> it;
            if (jsonObj.get(key).getClass() == JSONObject.class) {
                jsonObject = (JSONObject) jsonObj.get(key);
                Object jsonHash = new HashMap();
                it = jsonObject.keys();
                while (it.hasNext()) {
                    String jsonKey = (String) it.next();
                    jsonHash.put(jsonKey, parseObject(jsonKey, jsonObject));
                }
                return jsonHash;
            } else if (jsonObj.get(key).getClass() != JSONArray.class) {
                return jsonObj.get(key);
            } else {
                JSONArray jsonObjects = (JSONArray) jsonObj.get(key);
                int len = jsonObjects.length();
                ArrayList<HashMap<String, Object>> objects = new ArrayList();
                for (int i = 0; i < len; i++) {
                    jsonObject = (JSONObject) jsonObjects.get(i);
                    HashMap<String, Object> arrayInHash = new HashMap();
                    it = jsonObject.keys();
                    while (it.hasNext()) {
                        String objectKey = (String) it.next();
                        arrayInHash.put(objectKey, parseObject(objectKey, jsonObject));
                    }
                    objects.add(arrayInHash);
                }
                return objects;
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public JSONObject getBody() {
        try {
            return this.json.getJSONObject("data");
        } catch (JSONException e) {
            e.printStackTrace();
            return new JSONObject();
        }
    }

    public HashMap<String, Object> getJsonMap() {
        HashMap<String, Object> jsonMap = new HashMap();
        Iterator<?> i = this.json.keys();
        while (i.hasNext()) {
            String key = (String) i.next();
            jsonMap.put(key, parseObject(key, this.json));
        }
        return jsonMap;
    }

    public Integer getErrorCode() {
        if (this.error == null) {
            return null;
        }
        return Integer.valueOf(this.error.getErrorCode());
    }

    public String getErrorMsg() {
        if (this.error == null) {
            return null;
        }
        return this.error.getErrorMessage();
    }
}
