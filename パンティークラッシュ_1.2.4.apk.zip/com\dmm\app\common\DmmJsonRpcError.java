package com.dmm.app.common;

public class DmmJsonRpcError {
    private static final int BADUSER_ERROR_CODE = 100002;
    private static final String BADUSER_ERROR_MESSAGE = "ユーザーIDまたはパスワードが正しくありません。";
    private static final int CANTUSE_ERROR_CODE = 1000;
    private static final String CANTUSE_ERROR_MESSAGE = "ユーザーIDまたはパスワードが正しくありません。";
    private static final int COUNTRY_ERROR_CODE = 100008;
    private static final String COUNTRY_ERROR_MESSAGE = "ログインに失敗しました。サポートまでお問い合わせください。";
    private static final int DEFAULT_CODE = 9999;
    private static final String DEFAULT_MESSAGE = "予期せぬエラーが発生しました";
    private static final int DIGITAL_CREATEMYLIST_MAXIMUM_CODE = 300000;
    private static final String DIGITAL_CREATEMYLIST_MAXIMUM_MESSAGE = "選択されたマイリストへの登録件数が上限の30件を達したため、追加をキャンセルしました。";
    private static final int IDPW_ERROR_CODE = 500;
    private static final String IDPW_ERROR_MESSAGE = "ユーザーIDまたはパスワードが正しくありません。";
    private static final int MAILLOCK_ERROR_CODE = 100007;
    private static final String MAILLOCK_ERROR_MESSAGE = "メール認証が必要です。";
    private static final int MAINTENANCE_ERROR_CODE = 210;
    private static final int MAINTENANCE_ERROR_CODE_2 = 200;
    private static final String MAINTENANCE_ERROR_MESSAGE = "メンテナンス中です。しばらく時間をおいてお試しください。";
    private static final int SYSTEM_ERROR_CODE = 100;
    private static final int SYSTEM_ERROR_CODE_2 = 300;
    private static final String SYSTEM_ERROR_MESSAGE = "システムエラーが発生しました。";
    private static final int TRY_ERROR_CODE = 511;
    private static final String TRY_ERROR_MESSAGE = "一定回数のログインに失敗した為、お客様のユーザーIDは只今ご利用いただけません。";
    private int errorCode = DEFAULT_CODE;
    private String errorMessage = DEFAULT_MESSAGE;

    public int getErrorCode() {
        return this.errorCode;
    }

    public String getErrorMessage() {
        return this.errorMessage;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public void checkError(int errorCode, String errorMessage) {
        switch (errorCode) {
            case 100:
                setErrorCode(errorCode);
                setErrorMessage(SYSTEM_ERROR_MESSAGE);
                return;
            case 200:
            case 210:
                setErrorCode(errorCode);
                setErrorMessage(MAINTENANCE_ERROR_MESSAGE);
                return;
            case 300:
            case 500:
                setErrorCode(errorCode);
                setErrorMessage("ユーザーIDまたはパスワードが正しくありません。");
                return;
            case 511:
                setErrorCode(errorCode);
                setErrorMessage(TRY_ERROR_MESSAGE);
                return;
            case 1000:
                setErrorCode(errorCode);
                setErrorMessage("ユーザーIDまたはパスワードが正しくありません。");
                return;
            case 100002:
                setErrorCode(errorCode);
                setErrorMessage("ユーザーIDまたはパスワードが正しくありません。");
                return;
            case 100007:
                setErrorCode(errorCode);
                setErrorMessage(MAILLOCK_ERROR_MESSAGE);
                return;
            case 100008:
                setErrorCode(errorCode);
                setErrorMessage(COUNTRY_ERROR_MESSAGE);
                return;
            case DIGITAL_CREATEMYLIST_MAXIMUM_CODE /*300000*/:
                setErrorCode(errorCode);
                setErrorMessage(DIGITAL_CREATEMYLIST_MAXIMUM_MESSAGE);
                return;
            default:
                setErrorCode(errorCode);
                setErrorMessage(DEFAULT_MESSAGE);
                return;
        }
    }
}
