package com.dmm.app.common;

import com.dmm.app.base.Message;

public class DmmMessages {
    public static final String[] API_CAST_ERR = new String[]{"A003", "システムエラーが発生しました。"};
    public static final String[] API_CONNECT_ERR = new String[]{"A017", "通信エラーが発生しました。"};
    public static final String[] API_GENERAL_ERR = new String[]{"A031", "システムエラーが発生しました。"};
    public static final String[] API_PARAMS_ERR = new String[]{"A001", "システムエラーが発生しました。"};
    public static final String[] API_PARSE_ERR = new String[]{"A002", "システムエラーが発生しました。"};
    public static final String[] APP_COOPERATION_ERR = new String[]{"A018", "該当ページへの移動に失敗しました。\nトップページへ移動します。"};
    public static final String[] AUTHLIB_AUTH_ERR = new String[]{"A026", "ユーザー認証に失敗しました。"};
    public static final String[] AUTHLIB_COOPERATION_ERR = new String[]{"A027", "DMMアプリの起動に失敗しました。"};
    public static final String[] AUTHLIB_ILLEGALTOKEN_ERR = new String[]{"A030", "認証情報が一致しません。\nもう一度ログインしなおしてください。"};
    public static final String[] AUTHLIB_LOGIN_ERR = new String[]{"A028", "DMMへのログインに失敗しました。"};
    public static final String[] AUTHLIB_SAVETOKEN_ERR = new String[]{"A029", ""};
    public static final String[] DEVICE_GETPACKAGE_ERR = new String[]{"A016", "システムエラーが発生しました。"};
    public static final String[] DIR_DELETE_ERR = new String[]{"A009", "システムエラーが発生しました。"};
    public static final String[] DIR_MAKE_ERR = new String[]{"A008", "システムエラーが発生しました。"};
    public static final String[] DL_DUPLICATION_ERR = new String[]{"A024", "既にダウンロード中です。"};
    public static final String[] DL_MAKEFILE_ERR = new String[]{"A022", "システムエラーが発生しました。"};
    public static final String[] DL_NETCONNECTION_ERR = new String[]{"A023", "通信エラーが発生しました。"};
    public static final String[] DL_PARAMS_ERR = new String[]{"A020", "空き容量が不足しています。"};
    public static final String[] DL_QUEUE_ERR = new String[]{"A021", "同時ダウンロード数の上限に達しました。\nダウンロードが終わるまでしばらくお待ちください。"};
    public static final String[] FILE_DELETE_ERR = new String[]{"A007", "ファイルの削除ができませんでした。"};
    public static final String[] FILE_NOTEXISTS_ERR = new String[]{"A005", "ファイルの読込みに失敗しました。"};
    public static final String[] FILE_READ_ERR = new String[]{"A006", "ファイルの読込みに失敗しました。"};
    public static final String[] FILE_SAVE_ERR = new String[]{"A004", Message.ERR_PASSFILE_SAVE_FAILED};
    public static final String[] ID_INVALID_ERR = new String[]{"A033", "データの取得に失敗しました。通信状況等をお確かめの上再度お試しください。"};
    public static final String[] INPUT_CONVERTDATE_ERR = new String[]{"A013", "入力内容を確認してください。"};
    public static final String[] INPUT_LOGIN_ERR = new String[]{"A032", "ログインIDかパスワードが未入力です。"};
    public static final String[] INPUT_PARAMS_ERR = new String[]{"A012", "入力内容を確認してください。"};
    public static final String[] MARKET_AUTHINFO_ERR = new String[]{"A025", "システムエラーが発生しました。"};
    public static final String[] MARKET_GENERAL_ERR = new String[]{"A100", "システムエラーが発生しました。"};
    public static final String[] NETWORK_CONNECT_ERR = new String[]{"A019", "ネットワークに接続出来ませんでした。\n通信環境をお確かめください。"};
    public static final String[] SQL_EXECUTE_ERR = new String[]{"A011", "システムエラーが発生しました。"};
    public static final String[] SQL_PARAMS_ERR = new String[]{"A010", "システムエラーが発生しました。"};
    public static final String[] STRING_ENCRYPTION_ERR = new String[]{"A014", "システムエラーが発生しました。"};
    public static final String[] URL_PARSE_ERR = new String[]{"A015", "システムエラーが発生しました。"};

    public static String getUserErrorMsg(String[] messageInfo) {
        if (messageInfo == null) {
            return getUserErrorMsg(null, null);
        }
        if (messageInfo.length >= 2) {
            return getUserErrorMsg(messageInfo[0], messageInfo[1]);
        }
        return getUserErrorMsg(null, null);
    }

    public static String getUserErrorMsg(String code, String msg) {
        if (DmmCommonUtil.isEmpty(msg)) {
            msg = API_GENERAL_ERR[1];
            code = API_GENERAL_ERR[0];
        }
        if (DmmCommonUtil.isEmpty(code)) {
            return msg;
        }
        return String.format("%s(%s)", new Object[]{msg, code});
    }
}
