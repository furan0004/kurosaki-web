package com.dmm.app.common;

public final class Encryptor {
    public static native byte[] nativeGenerateKey(String str);

    static {
        System.loadLibrary("encryptor");
    }

    private Encryptor() {
    }

    public static byte[] generateKey(String seed) {
        return nativeGenerateKey(seed);
    }
}
