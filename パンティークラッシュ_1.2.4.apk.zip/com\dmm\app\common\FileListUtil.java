package com.dmm.app.common;

import java.io.File;
import java.util.TreeSet;

public class FileListUtil {
    public static final int TYPE_DIR = 3;
    public static final int TYPE_FILE = 2;
    public static final int TYPE_FILE_OR_DIR = 1;
    private TreeSet<File> set = new TreeSet();

    public File[] listFiles(String dirPath, int type) {
        return listFiles(dirPath, type, Boolean.valueOf(false));
    }

    public File[] listFiles(String dirPath, int type, Boolean isRecursive) {
        if (dirPath == null) {
            throw new IllegalArgumentException("is not directory");
        } else if (type == 1 || type == 2 || type == 3) {
            File dir = new File(dirPath);
            if (dir.isDirectory()) {
                File[] files = dir.listFiles();
                for (File file : files) {
                    addFile(type, file, this.set);
                    if (isRecursive.booleanValue() && file.isDirectory()) {
                        listFiles(file.getAbsolutePath(), type, isRecursive);
                    }
                }
                return (File[]) this.set.toArray(new File[this.set.size()]);
            }
            throw new IllegalArgumentException(dir.getAbsolutePath() + " is not directory");
        } else {
            throw new IllegalArgumentException("paramator error(type)");
        }
    }

    private static void addFile(int type, File file, TreeSet<File> set) {
        switch (type) {
            case 1:
                break;
            case 2:
                if (!file.isFile()) {
                    return;
                }
                break;
            case 3:
                if (!file.isDirectory()) {
                    return;
                }
                break;
            default:
                return;
        }
        set.add(file);
    }
}
