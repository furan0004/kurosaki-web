package com.dmm.app.common;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import android.support.v4.media.session.PlaybackStateCompat;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public final class FileUtil {
    private static final String ENCODE = "UTF-8";
    private static final String EXTERNAL_SD = "external_sd";
    private static final String EXT_SD = "ext_sd";
    private static final String FS_SETTINGS = "/system/etc/vold.fstab";
    private static final String MOUNTS = "/proc/mounts";
    private static final String SDCARD1 = "sdcard1";
    private static final String STORAGE = "dev_mount";
    private static final Map<String, String> STORAGE_INFO = new HashMap();

    static {
        STORAGE_INFO.put("/storage/sdcard1", "/storage/removable/sdcard1");
    }

    private FileUtil() {
        throw new UnsupportedOperationException();
    }

    public static String getExternalStoragePath() {
        String retPath = "";
        List<String> paths = getExternalStoragePaths();
        if (paths.size() < 1) {
            String vertualSdPath = Environment.getExternalStorageDirectory().getPath();
            if (DmmCommonUtil.isEmpty(vertualSdPath)) {
                return null;
            }
            return vertualSdPath;
        }
        for (String path : paths) {
            if ("".equals(retPath) || retPath.length() < path.length() || path.indexOf(SDCARD1) != -1 || path.indexOf(EXT_SD) != -1 || path.indexOf(EXTERNAL_SD) != -1) {
                retPath = path;
            }
        }
        return retPath;
    }

    public static List<String> getExternalStoragePaths() {
        Exception e;
        Throwable th;
        List<String> exStoragePaths = new ArrayList();
        Scanner scanner = null;
        try {
            Scanner scanner2 = new Scanner(new FileInputStream(new File(FS_SETTINGS)));
            while (scanner2.hasNextLine()) {
                try {
                    String line = scanner2.nextLine();
                    if (line.startsWith(STORAGE)) {
                        String path = line.split(" ")[2];
                        if (!exStoragePaths.contains(path)) {
                            exStoragePaths.add(path);
                        }
                    }
                } catch (Exception e2) {
                    e = e2;
                    scanner = scanner2;
                } catch (Throwable th2) {
                    th = th2;
                    scanner = scanner2;
                }
            }
            if (scanner2 != null) {
                scanner2.close();
            }
            scanner = scanner2;
            return getMountedPaths(exStoragePaths);
        } catch (Exception e3) {
            e = e3;
            try {
                e.printStackTrace();
                List<String> arrayList = new ArrayList();
                if (scanner == null) {
                    return arrayList;
                }
                scanner.close();
                return arrayList;
            } catch (Throwable th3) {
                th = th3;
                if (scanner != null) {
                    scanner.close();
                }
                throw th;
            }
        }
    }

    public static boolean createFile(String path, String data) {
        Exception e;
        Throwable th;
        if (DmmCommonUtil.isEmpty(path)) {
            return false;
        }
        new File(path).getParentFile().mkdir();
        BufferedWriter bw = null;
        try {
            BufferedWriter bw2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path), "UTF-8"));
            try {
                bw2.write(data);
                bw2.flush();
                if (bw2 != null) {
                    try {
                        bw2.close();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        return false;
                    }
                }
                return true;
            } catch (Exception e3) {
                e = e3;
                bw = bw2;
                try {
                    e.printStackTrace();
                    if (bw != null) {
                        return false;
                    }
                    try {
                        bw.close();
                        return false;
                    } catch (IOException e22) {
                        e22.printStackTrace();
                        return false;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (bw != null) {
                        try {
                            bw.close();
                        } catch (IOException e222) {
                            e222.printStackTrace();
                            return false;
                        }
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                bw = bw2;
                if (bw != null) {
                    bw.close();
                }
                throw th;
            }
        } catch (Exception e4) {
            e = e4;
            e.printStackTrace();
            if (bw != null) {
                return false;
            }
            bw.close();
            return false;
        }
    }

    public static boolean createFileToPhone(Context context, String fileName, String data) {
        Exception e;
        Throwable th;
        if (DmmCommonUtil.isEmpty(fileName)) {
            return false;
        }
        BufferedWriter bw = null;
        try {
            BufferedWriter bw2 = new BufferedWriter(new OutputStreamWriter(context.openFileOutput(fileName, 0)));
            try {
                bw2.write(data);
                bw2.flush();
                if (bw2 != null) {
                    try {
                        bw2.close();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        return false;
                    }
                }
                return true;
            } catch (Exception e3) {
                e = e3;
                bw = bw2;
                try {
                    e.printStackTrace();
                    if (bw != null) {
                        return false;
                    }
                    try {
                        bw.close();
                        return false;
                    } catch (IOException e22) {
                        e22.printStackTrace();
                        return false;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (bw != null) {
                        try {
                            bw.close();
                        } catch (IOException e222) {
                            e222.printStackTrace();
                            return false;
                        }
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                bw = bw2;
                if (bw != null) {
                    bw.close();
                }
                throw th;
            }
        } catch (Exception e4) {
            e = e4;
            e.printStackTrace();
            if (bw != null) {
                return false;
            }
            bw.close();
            return false;
        }
    }

    public static String readFile(String path) {
        Exception e;
        Throwable th;
        String result = "";
        BufferedReader br = null;
        try {
            BufferedReader br2 = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
            while (true) {
                try {
                    String tmpline = br2.readLine();
                    if (tmpline == null) {
                        break;
                    }
                    if (0 > 0) {
                        result = new StringBuilder(String.valueOf(result)).append("\n").toString();
                    }
                    result = new StringBuilder(String.valueOf(result)).append(tmpline).toString();
                } catch (Exception e2) {
                    e = e2;
                    br = br2;
                } catch (Throwable th2) {
                    th = th2;
                    br = br2;
                }
            }
            if (br2 != null) {
                try {
                    br2.close();
                } catch (IOException e3) {
                    e3.printStackTrace();
                    br = br2;
                    return null;
                }
            }
            br = br2;
            return result;
        } catch (Exception e4) {
            e = e4;
            try {
                e.printStackTrace();
                if (br == null) {
                    return null;
                }
                try {
                    br.close();
                    return null;
                } catch (IOException e32) {
                    e32.printStackTrace();
                    return null;
                }
            } catch (Throwable th3) {
                th = th3;
                if (br != null) {
                    try {
                        br.close();
                    } catch (IOException e322) {
                        e322.printStackTrace();
                        return null;
                    }
                }
                throw th;
            }
        }
    }

    public static String readFileFromPhone(Context context, String fileName) {
        Exception e;
        Throwable th;
        String result = "";
        BufferedReader br = null;
        try {
            BufferedReader br2 = new BufferedReader(new InputStreamReader(context.openFileInput(fileName)));
            while (true) {
                try {
                    String tmpline = br2.readLine();
                    if (tmpline == null) {
                        break;
                    }
                    if (0 > 0) {
                        result = new StringBuilder(String.valueOf(result)).append("\n").toString();
                    }
                    result = new StringBuilder(String.valueOf(result)).append(tmpline).toString();
                } catch (Exception e2) {
                    e = e2;
                    br = br2;
                } catch (Throwable th2) {
                    th = th2;
                    br = br2;
                }
            }
            if (br2 != null) {
                try {
                    br2.close();
                } catch (IOException e3) {
                    e3.printStackTrace();
                    br = br2;
                    return null;
                }
            }
            br = br2;
            return result;
        } catch (Exception e4) {
            e = e4;
            try {
                e.printStackTrace();
                if (br == null) {
                    return null;
                }
                try {
                    br.close();
                    return null;
                } catch (IOException e32) {
                    e32.printStackTrace();
                    return null;
                }
            } catch (Throwable th3) {
                th = th3;
                if (br != null) {
                    try {
                        br.close();
                    } catch (IOException e322) {
                        e322.printStackTrace();
                        return null;
                    }
                }
                throw th;
            }
        }
    }

    public static String loadJsonFileFromAssets(Context context, String fileName) throws IOException {
        InputStream is = context.getAssets().open(fileName);
        byte[] buffer = new byte[is.available()];
        is.read(buffer);
        is.close();
        return new String(buffer);
    }

    public static boolean removeFile(String path) {
        if (DmmCommonUtil.isEmpty(path)) {
            return false;
        }
        try {
            File file = new File(path);
            if (!file.exists() || remove(file)) {
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static FileUtilResult removeFile(String[] paths) {
        FileUtilResult result = new FileUtilResult();
        result.setSuccess(true);
        if (paths.length < 1) {
            result.setSuccess(false);
        } else {
            ArrayList<String> failedPaths = new ArrayList();
            for (String row : paths) {
                if (!removeFile(row)) {
                    result.setSuccess(false);
                    failedPaths.add(row);
                }
            }
            result.setPaths(failedPaths);
        }
        return result;
    }

    private static boolean remove(File file) {
        int i = 0;
        if (file == null || !file.exists()) {
            return false;
        }
        if (file.isFile()) {
            return file.delete();
        }
        File[] children = file.listFiles();
        int length = children.length;
        while (i < length) {
            remove(children[i]);
            i++;
        }
        return file.delete();
    }

    private static List<String> getMountedPaths(List<String> paths) {
        Exception e;
        List<String> mountedPaths = new ArrayList();
        Scanner scanner = null;
        try {
            Scanner scanner2 = null;
            for (String path : paths) {
                try {
                    scanner = new Scanner(new FileInputStream(new File(MOUNTS)));
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        if (line.contains(path) && !mountedPaths.contains(path)) {
                            mountedPaths.add(path);
                            scanner2 = scanner;
                            break;
                        }
                        String mountPath = (String) STORAGE_INFO.get(path);
                        if (!DmmCommonUtil.isEmpty(mountPath) && line.contains(mountPath) && !mountedPaths.contains(mountPath)) {
                            mountedPaths.add(path);
                            scanner2 = scanner;
                            break;
                        }
                    }
                    scanner2 = scanner;
                } catch (Exception e2) {
                    e = e2;
                    scanner = scanner2;
                } catch (Throwable th) {
                    Throwable th2 = th;
                    scanner = scanner2;
                }
            }
            if (scanner2 != null) {
                scanner2.close();
            }
            scanner = scanner2;
        } catch (Exception e3) {
            e = e3;
        }
        return mountedPaths;
        try {
            e.printStackTrace();
            mountedPaths = new ArrayList();
            if (scanner != null) {
                scanner.close();
            }
            return mountedPaths;
        } catch (Throwable th3) {
            th2 = th3;
            if (scanner != null) {
                scanner.close();
            }
            throw th2;
        }
    }

    public static Boolean checkFileSize(String mntArea, long totalBytes) {
        if (DmmCommonUtil.isEmpty(mntArea)) {
            return Boolean.valueOf(true);
        }
        StatFs statFs = new StatFs(mntArea);
        if (totalBytes / PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID > (((long) statFs.getBlockSize()) * ((long) statFs.getAvailableBlocks())) / PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID) {
            return Boolean.valueOf(true);
        }
        return Boolean.valueOf(false);
    }
}
