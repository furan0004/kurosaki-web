package com.dmm.app.common;

import java.util.ArrayList;

public class FileUtilResult {
    private boolean isSuccess;
    private ArrayList<String> paths;

    public boolean isSuccess() {
        return this.isSuccess;
    }

    public void setSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public ArrayList<String> getPaths() {
        return this.paths;
    }

    public void setPaths(ArrayList<String> paths) {
        this.paths = paths;
    }
}
