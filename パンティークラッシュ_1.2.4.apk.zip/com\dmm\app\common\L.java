package com.dmm.app.common;

import android.util.Log;

public final class L {
    private static final String DEFAULT_TAG = "L";
    private static Boolean LV_DEBUG = Boolean.valueOf(true);
    private static Boolean LV_ERROR = Boolean.valueOf(true);
    private static Boolean LV_INFO = Boolean.valueOf(true);
    private static Boolean LV_VERBOSE = Boolean.valueOf(true);
    private static Boolean LV_WARN = Boolean.valueOf(true);

    private L() {
    }

    public static Boolean d(String msg) {
        return d(DEFAULT_TAG, msg, null);
    }

    public static Boolean d(String tag, String msg) {
        return d(tag, msg, null);
    }

    public static Boolean d(String tag, String msg, Throwable tr) {
        if (!LV_DEBUG.booleanValue()) {
            return Boolean.valueOf(false);
        }
        if (tr == null) {
            Log.d(tag, msg);
        } else {
            Log.d(tag, msg, tr);
        }
        return Boolean.valueOf(true);
    }

    public static Boolean v(String msg) {
        return v(DEFAULT_TAG, msg, null);
    }

    public static Boolean v(String tag, String msg) {
        return v(tag, msg, null);
    }

    public static Boolean v(String tag, String msg, Throwable tr) {
        if (!LV_VERBOSE.booleanValue()) {
            return Boolean.valueOf(false);
        }
        if (tr == null) {
            Log.v(tag, msg);
        } else {
            Log.v(tag, msg, tr);
        }
        return Boolean.valueOf(true);
    }

    public static Boolean i(String msg) {
        return i(DEFAULT_TAG, msg, null);
    }

    public static Boolean i(String tag, String msg) {
        return i(tag, msg, null);
    }

    public static Boolean i(String tag, String msg, Throwable tr) {
        if (!LV_INFO.booleanValue()) {
            return Boolean.valueOf(false);
        }
        if (tr == null) {
            Log.i(tag, msg);
        } else {
            Log.i(tag, msg, tr);
        }
        return Boolean.valueOf(true);
    }

    public static Boolean w(String msg) {
        return w(DEFAULT_TAG, msg, null);
    }

    public static Boolean w(String tag, String msg) {
        return w(tag, msg, null);
    }

    public static Boolean w(String tag, String msg, Throwable tr) {
        if (!LV_WARN.booleanValue()) {
            return Boolean.valueOf(false);
        }
        if (tr == null) {
            Log.w(tag, msg);
        } else {
            Log.w(tag, msg, tr);
        }
        return Boolean.valueOf(true);
    }

    public static Boolean e(String msg) {
        return e(DEFAULT_TAG, msg, null);
    }

    public static Boolean e(String tag, String msg) {
        return e(tag, msg, null);
    }

    public static Boolean e(String tag, String msg, Throwable tr) {
        if (!LV_ERROR.booleanValue()) {
            return Boolean.valueOf(false);
        }
        if (tr == null) {
            Log.e(tag, msg);
        } else {
            Log.e(tag, msg, tr);
        }
        return Boolean.valueOf(true);
    }

    public static void logLvConf(Boolean config) {
        LV_DEBUG = config;
        LV_VERBOSE = config;
        LV_WARN = config;
        LV_ERROR = config;
        LV_INFO = config;
    }
}
