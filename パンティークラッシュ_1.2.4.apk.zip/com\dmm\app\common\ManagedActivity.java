package com.dmm.app.common;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.util.SparseArray;

public class ManagedActivity extends Activity {
    private SparseArray<ManagedDialog> managedDialogs;

    protected static class ManagedDialog {
        public static final int STATUS_HIDDEN = 1;
        public static final int STATUS_SHOWING = 0;
        private Bundle args;
        private Dialog dialog;
        private int id;
        private int status;

        protected ManagedDialog() {
        }

        public int getId() {
            return this.id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public Dialog getDialog() {
            return this.dialog;
        }

        public void setDialog(Dialog dialog) {
            this.dialog = dialog;
        }

        public Bundle getArgs() {
            return this.args;
        }

        public void setArgs(Bundle args) {
            this.args = args;
        }

        public int getStatus() {
            return this.status;
        }

        public void setStatus(int status) {
            this.status = status;
        }
    }

    protected final Dialog setCreatedDialog(int id, Dialog dialog) {
        return setCreatedDialog(id, dialog, null);
    }

    protected final Dialog setCreatedDialog(int id, Dialog dialog, Bundle args) {
        if (this.managedDialogs == null) {
            this.managedDialogs = new SparseArray();
        }
        ManagedDialog data = new ManagedDialog();
        data.setId(id);
        data.setDialog(dialog);
        data.setArgs(args);
        data.setStatus(1);
        this.managedDialogs.put(id, data);
        return dialog;
    }

    public final boolean showManagedDialog(int id) {
        return showManagedDialog(id, null);
    }

    public final boolean showManagedDialog(int id, Bundle args) {
        if (this.managedDialogs == null) {
            this.managedDialogs = new SparseArray();
        }
        ManagedDialog md = (ManagedDialog) this.managedDialogs.get(id);
        if (md == null) {
            md = new ManagedDialog();
            md.setDialog(onCreateDialog(id, args));
            if (md.getDialog() == null) {
                return false;
            }
            this.managedDialogs.put(id, md);
        }
        md.setId(id);
        md.setArgs(args);
        md.setStatus(0);
        onPrepareDialog(id, md.getDialog(), args);
        md.getDialog().show();
        return true;
    }

    public final void dismissManagedDialog(int id) {
        if (this.managedDialogs == null) {
            throw missingDialog(id);
        }
        ManagedDialog md = (ManagedDialog) this.managedDialogs.get(id);
        if (md == null) {
            throw missingDialog(id);
        }
        md.setStatus(1);
        md.getDialog().dismiss();
    }

    public final void removeManagedDialog(int id) {
        if (this.managedDialogs != null) {
            ManagedDialog md = (ManagedDialog) this.managedDialogs.get(id);
            if (md != null) {
                md.getDialog().dismiss();
                this.managedDialogs.remove(id);
            }
        }
    }

    protected void onDestroy() {
        if (this.managedDialogs != null) {
            int numDialogs = this.managedDialogs.size();
            for (int i = 0; i < numDialogs; i++) {
                ManagedDialog md = (ManagedDialog) this.managedDialogs.valueAt(i);
                if (md.getDialog().isShowing()) {
                    md.getDialog().dismiss();
                }
            }
            this.managedDialogs = null;
        }
        super.onDestroy();
    }

    protected SparseArray<ManagedDialog> getManagedDialogs() {
        return this.managedDialogs;
    }

    private IllegalArgumentException missingDialog(int id) {
        return new IllegalArgumentException("no dialog with id " + id + " was ever " + "shown via ManagedActivity#xxxxManagedDialog");
    }
}
