package com.dmm.app.common;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class TextProgressBar extends ProgressBar {
    private static final int DEFAULT_FONT_SIZE = 15;
    private Rect bounds = new Rect();
    private String text = "";
    private int textColor = ViewCompat.MEASURED_STATE_MASK;
    private Paint textPaint = new Paint();
    private float textSize = 15.0f;

    public TextProgressBar(Context context) {
        super(context);
    }

    public TextProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public TextProgressBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.textPaint.setAntiAlias(true);
        this.textPaint.setColor(this.textColor);
        this.textPaint.setTextSize(this.textSize);
        this.textPaint.getTextBounds(this.text, 0, this.text.length(), this.bounds);
        canvas.drawText(this.text, (float) ((getWidth() / 2) - this.bounds.centerX()), (float) ((getHeight() / 2) - this.bounds.centerY()), this.textPaint);
    }

    public String getText() {
        return this.text;
    }

    public synchronized void setText(String text) {
        if (text != null) {
            this.text = text;
        } else {
            this.text = "";
        }
        postInvalidate();
    }

    public int getTextColor() {
        return this.textColor;
    }

    public synchronized void setTextColor(int textColor) {
        this.textColor = textColor;
        postInvalidate();
    }

    public float getTextSize() {
        return this.textSize;
    }

    public synchronized void setTextSize(float textSize) {
        this.textSize = textSize;
        postInvalidate();
    }

    public Paint getTextPaint() {
        return this.textPaint;
    }

    public void setTextPaint(Paint textPaint) {
        this.textPaint = textPaint;
    }

    public Rect getBounds() {
        return this.bounds;
    }

    public void setBounds(Rect bounds) {
        this.bounds = bounds;
    }
}
