package com.dmm.app.connection;

import android.content.Context;
import android.content.res.Resources;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.dmm.app.common.DmmCommonUtil;
import com.dmm.app.common.R;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.Map.Entry;

public class ApiConnection<T> {
    public static final String[] API_PARAMS_ERR = new String[]{"A001", "システムエラーが発生しました。"};
    private Context context;
    private Class<T> entity;
    private ErrorListener errorListener = new ErrorListener() {
        public void onErrorResponse(VolleyError error) {
            String message;
            error.printStackTrace();
            if ((error.getCause() instanceof JsonSyntaxException) || (error.getCause() instanceof UnsupportedEncodingException)) {
                message = ApiConnection.this.context.getString(R.string.error_system_message);
            } else {
                message = ApiConnection.this.context.getString(R.string.error_network_message);
            }
            Toast.makeText(ApiConnection.this.context, message, 1).show();
        }
    };
    protected DmmListener<T> listener;
    private RequestQueue mQueue;
    private String message;
    private Map<String, String> params;
    private String[] requiredParamNames;

    public ApiConnection(Context context, String message, Map<String, String> params, Class<T> entity, DmmListener<T> listener) {
        this.context = context;
        this.message = message;
        this.params = params;
        this.entity = entity;
        this.listener = listener;
        this.mQueue = DmmRequestHolder.newRequestQueue(context);
    }

    public ApiConnection(Context context, String message, Map<String, String> params, Class<T> entity, DmmListener<T> listener, ErrorListener errorListener) {
        this.context = context;
        this.message = message;
        this.params = params;
        this.entity = entity;
        this.listener = listener;
        this.errorListener = errorListener;
        this.mQueue = DmmRequestHolder.newRequestQueue(context);
    }

    public Boolean connection() {
        return connection(Boolean.valueOf(true));
    }

    public Boolean connection(Boolean showToast) {
        return connection(showToast, Boolean.valueOf(false), 0);
    }

    public Boolean connection(String tag) {
        return connection(Boolean.valueOf(true), Boolean.valueOf(false), 0, tag);
    }

    public Boolean connection(Boolean showToast, Boolean cacheFlg, int cacheExpiry) {
        return connection(showToast, cacheFlg, cacheExpiry, null);
    }

    public Boolean connection(Boolean showToast, Boolean cacheFlg, int cacheExpiry, String tag) {
        if (dataCheck(this.params)) {
            ApplicationKey appKey = getApplicationKey();
            if (appKey == null) {
                return Boolean.valueOf(false);
            }
            DmmApiRequest<T> apiRequest = new DmmApiRequest(this.message, this.params, appKey.getApplicationId(), appKey.getHashKey(), this.entity, this.listener, this.errorListener);
            if (cacheFlg.booleanValue()) {
                apiRequest.setShouldCache(cacheFlg.booleanValue());
                apiRequest.setCacheExpiry(cacheExpiry);
                apiRequest.setCacheKey(this.message);
            }
            if (!DmmCommonUtil.isEmpty(tag)) {
                apiRequest.setTag(tag);
            }
            this.mQueue.add(apiRequest);
            return Boolean.valueOf(true);
        }
        if (showToast.booleanValue()) {
            Toast.makeText(this.context, String.format("%s(%s)", new Object[]{API_PARAMS_ERR[1], API_PARAMS_ERR[0]}), 1).show();
        }
        return Boolean.valueOf(false);
    }

    public boolean dataCheck(Map<String, String> apiParams) {
        Boolean isParamsRight = Boolean.valueOf(true);
        int requiredNum = 0;
        for (Entry<String, String> param : apiParams.entrySet()) {
            for (String requiredParamName : this.requiredParamNames) {
                if (((String) param.getKey()).equals(requiredParamName)) {
                    requiredNum++;
                    if (DmmCommonUtil.isEmpty((String) param.getValue())) {
                        isParamsRight = Boolean.valueOf(false);
                    }
                }
            }
        }
        if (requiredNum < this.requiredParamNames.length) {
            isParamsRight = Boolean.valueOf(false);
        }
        return isParamsRight.booleanValue();
    }

    public String[] getRequiredParamNames() {
        return this.requiredParamNames;
    }

    public void setRequiredParamNames(String[] requiredParamNames) {
        this.requiredParamNames = requiredParamNames;
    }

    public void clearCache() {
        this.mQueue.getCache().remove(this.message);
    }

    public void cancelAll(String tag) {
        this.mQueue.cancelAll((Object) tag);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private ApplicationKey getApplicationKey() {
        String resourceName = "application_key";
        String raw = "raw";
        String packageName = this.context.getPackageName();
        Resources res = this.context.getResources();
        int resId = res.getIdentifier("application_key", "raw", packageName);
        if (resId == 0) {
            return null;
        }
        InputStream st = null;
        String appKeyJson = null;
        try {
            st = res.openRawResource(resId);
            byte[] buffer = new byte[st.available()];
            do {
            } while (st.read(buffer) != -1);
            String appKeyJson2 = new String(buffer);
            try {
                st.close();
                appKeyJson = appKeyJson2;
            } catch (IOException e) {
                e.printStackTrace();
                appKeyJson = appKeyJson2;
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (Throwable th) {
            try {
                st.close();
            } catch (IOException e22) {
                e22.printStackTrace();
            }
        }
        if (appKeyJson != null) {
            return (ApplicationKey) new Gson().fromJson(appKeyJson, ApplicationKey.class);
        }
        return null;
    }

    public DmmListener<T> getListener() {
        return this.listener;
    }

    public void setListener(DmmListener<T> listener) {
        this.listener = listener;
    }

    public ErrorListener getErrorListener() {
        return this.errorListener;
    }

    public void setErrorListener(ErrorListener errorListener) {
        this.errorListener = errorListener;
    }
}
