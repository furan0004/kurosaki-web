package com.dmm.app.connection;

public class ApiResult {
    private int error;
    private boolean event;
    private float exectime;
    private String memory;

    public boolean getEvent() {
        return this.event;
    }

    public void setEvent(boolean event) {
        this.event = event;
    }

    public float getExectime() {
        return this.exectime;
    }

    public void setExectime(float exectime) {
        this.exectime = exectime;
    }

    public String getMemory() {
        return this.memory;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }

    public int getError() {
        return this.error;
    }

    public void setError(int error) {
        this.error = error;
    }
}
