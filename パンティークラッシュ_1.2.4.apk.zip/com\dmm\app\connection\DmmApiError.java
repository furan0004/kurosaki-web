package com.dmm.app.connection;

public class DmmApiError {
    private static final String API_ERROR = "通信エラーが発生しました。";
    private static final String AUTH_ERROR = "ユーザーIDまたはパスワードが正しくありません。";
    private static final String AUTH_MAIL_ERROR = "メール認証が必要です。";
    private static final String DIGITAL_CONTENT_ERROR = "DMM動画アプリが別IDでログインされています。\n現在のアカウントと同じIDでログインしてください。";
    public static final int ERROR_100 = 100;
    public static final int ERROR_1000 = 1000;
    public static final int ERROR_100002 = 100002;
    public static final int ERROR_100007 = 100007;
    public static final int ERROR_100008 = 100008;
    public static final int ERROR_101 = 101;
    public static final int ERROR_200 = 200;
    public static final int ERROR_200000 = 200000;
    public static final int ERROR_200014 = 200014;
    public static final int ERROR_300 = 300;
    public static final int ERROR_301 = 301;
    public static final int ERROR_500 = 500;
    public static final int ERROR_510 = 510;
    public static final int ERROR_511 = 511;
    private static final String ERROR_MESSAGE_FORMAT = "エラーコード：%d\n%s";
    private static final String LANGUAGE_ERROR = "ログインに失敗しました。サポートまでお問い合わせください。";
    private static final String PASSWORD_CHANGE_ERROR = "一定の回数のログインに失敗しました。";
    private static final String SYSTEM_ERROR = "システムエラーが発生しました。";
    private static final String SYSTEM_MAINTENANCE_ERROR = "メンテナンス中です。\nしばらく時間をおいてお試し下さい。";
    private int mErrorCode;
    private String mErrorMessage;
    private String mErrorUrl;

    public DmmApiError(int errorCode) {
        this.mErrorCode = errorCode;
        this.mErrorUrl = "";
        errorCheck(errorCode);
    }

    public DmmApiError(int errorCode, String url) {
        this.mErrorCode = errorCode;
        this.mErrorUrl = url;
        errorCheck(errorCode);
    }

    public int getErrorCode() {
        return this.mErrorCode;
    }

    public String getErrorMessage() {
        return this.mErrorMessage;
    }

    public String getErrorUrl() {
        return this.mErrorUrl;
    }

    private void errorCheck(int errorCode) {
        String message;
        switch (errorCode) {
            case 100:
            case 101:
            case 300:
            case 301:
                message = SYSTEM_ERROR;
                break;
            case 200:
                message = SYSTEM_MAINTENANCE_ERROR;
                break;
            case 500:
            case 1000:
            case 100002:
                message = AUTH_ERROR;
                break;
            case 510:
                message = API_ERROR;
                break;
            case 511:
                message = PASSWORD_CHANGE_ERROR;
                break;
            case 100007:
                message = AUTH_MAIL_ERROR;
                break;
            case 100008:
                message = LANGUAGE_ERROR;
                break;
            case 200000:
                message = SYSTEM_MAINTENANCE_ERROR;
                break;
            case 200014:
                message = DIGITAL_CONTENT_ERROR;
                break;
            default:
                message = API_ERROR;
                break;
        }
        this.mErrorMessage = String.format(ERROR_MESSAGE_FORMAT, new Object[]{Integer.valueOf(this.mErrorCode), message});
    }
}
