package com.dmm.app.connection;

import com.dmm.asdk.core.store.GetHomeInfoConnection;
import com.google.gson.Gson;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class DmmApiParams {
    private static final String HASH_ALGORISM = "hmacSHA256";

    private DmmApiParams() {
    }

    public static String getJson(Map<String, String> params) {
        return new Gson().toJson((Object) params);
    }

    public static String getHash(String json, String hashKey) {
        SecretKeySpec secretKeySpec = new SecretKeySpec(hashKey.getBytes(), HASH_ALGORISM);
        try {
            Mac mac = Mac.getInstance(HASH_ALGORISM);
            mac.init(secretKeySpec);
            return byteToString(mac.doFinal(json.getBytes()));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        } catch (InvalidKeyException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    private static String byteToString(byte[] b) {
        StringBuffer buffer = new StringBuffer();
        for (int d : b) {
            int d2;
            if (d2 < 0) {
                d2 += 256;
            } else {
                d2 += 0;
            }
            if (d2 < 16) {
                buffer.append(GetHomeInfoConnection.ISADULT_FALSE);
            }
            buffer.append(Integer.toString(d2, 16));
        }
        return buffer.toString();
    }
}
